import csv
import pandas as pd


class Aggregator:

    def __init__(self):
        self.data = pd.read_csv('data_10sensors_1year.csv')
        self.data['Timestamp'] = pd.to_datetime(self.data['Timestamp'])

    def get_data(self):
        return self.__aggregate()

    def __aggregate(self):
        sens_list = 'Sensor0,Sensor1,Sensor2,Sensor3,Sensor4,Sensor5,Sensor6,Sensor7,Sensor8,Sensor9'.split(',')
        data = {}
        for s in sens_list:
            data[s] = self.data[self.data['SensorID'] == s]
        return data


